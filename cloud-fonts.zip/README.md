cloud-fonts
===========

This is a fork of 'php-font-proxy' a php-based webfont server created by Christopher Pitt (see https://github.com/amswindell/php-font-proxy)

php-font-proxy is a 'Google WebFonts clone you can serve from your own server, with your own fonts.'

This fork aims to add support for WOFF fonts and re-bundle the package to create a small, lightweight font server that can be easilly distributed, simply installed and run on standard hosted web space. 
