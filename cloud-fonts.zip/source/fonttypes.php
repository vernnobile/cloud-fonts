<?php

class FontTypes
{
	const OTF = 'opentype';
	const TTF = 'truetype';
	const EOT = 'eot';
	const WOFF = 'woff';
}
